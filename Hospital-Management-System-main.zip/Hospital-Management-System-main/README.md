**Home Page**
![image](https://github.com/Karthikg1908/Hospital-Management-System/assets/86306862/9c96ffcb-2bef-484b-a996-548fde802a26)
![image](https://github.com/Karthikg1908/Hospital-Management-System/assets/86306862/f960b36c-a726-4e02-8416-0284d2f1f9e9)
![image](https://github.com/Karthikg1908/Hospital-Management-System/assets/86306862/4c583894-e124-4606-a971-c9925bdf23ad)

**Admin Login Page**

![image](https://github.com/Karthikg1908/Hospital-Management-System/assets/86306862/52b69f80-9912-418b-b6e0-df47c4c2447c)

**Admin Dashboard**

![image](https://github.com/Karthikg1908/Hospital-Management-System/assets/86306862/439231fb-ee57-4e7f-8625-586436866e1b)

**ADMIN | MANAGE DOCTORS**

![image](https://github.com/Karthikg1908/Hospital-Management-System/assets/86306862/8909c579-3ac2-46c0-a7d4-f7f323d23ebc)

**ADMIN | MANAGE USERS**

![image](https://github.com/Karthikg1908/Hospital-Management-System/assets/86306862/d7e1b1e4-813f-4742-9cbf-32a94a4749ac)

**PATIENTS | APPOINTMENT HISTORY**

![image](https://github.com/Karthikg1908/Hospital-Management-System/assets/86306862/b01f5276-f3e7-4318-90a5-3b86b3f77efb)

**ADMIN | DOCTOR SESSION LOGS**

![image](https://github.com/Karthikg1908/Hospital-Management-System/assets/86306862/78b3771a-8c40-483d-9fc1-e308cf993c63)

**ADMIN | USER SESSION LOGS**

![image](https://github.com/Karthikg1908/Hospital-Management-System/assets/86306862/da39ced7-edd0-4fd3-b3ee-452f1f29f8c3)

**HMS | Doctor Login**

![image](https://github.com/Karthikg1908/Hospital-Management-System/assets/86306862/93fcb022-7966-462d-bf74-986fc719da56)

**DOCTOR | DASHBOARD**

![image](https://github.com/Karthikg1908/Hospital-Management-System/assets/86306862/eae4aaad-e92a-4cce-91f7-a9730eef90a2)

**USER | DASHBOARD**

![image](https://github.com/Karthikg1908/Hospital-Management-System/assets/86306862/2e881744-4ad4-4cc3-b5c0-c120e6f86933)

**USER | BOOK APPOINTMENT**

![image](https://github.com/Karthikg1908/Hospital-Management-System/assets/86306862/46581076-eaba-4538-a868-8a445642d015)

**USER | APPOINTMENT RECEIPT**

![image](https://github.com/Karthikg1908/Hospital-Management-System/assets/86306862/e054e4de-3775-4c69-8dac-03ca4b45522e)

![image](https://github.com/Karthikg1908/Hospital-Management-System/assets/86306862/7e241d03-f6e1-4cca-bcff-69588ab3a206)

![image](https://github.com/Karthikg1908/Hospital-Management-System/assets/86306862/481f73a6-a5a1-4f38-87e3-dcab6d5f446b)

![image](https://github.com/Karthikg1908/Hospital-Management-System/assets/86306862/07219741-63a4-4702-b7fb-a262a8889079)

**DOWNLOADED RECEIPT**

![screenshot (3)](https://github.com/Karthikg1908/Hospital-Management-System/assets/86306862/ffa17dde-3bea-4b9d-bcd0-982cca0ab6c4)


***USER | APPOINTMENT RECEIPT Download**

![image](https://github.com/Karthikg1908/Hospital-Management-System/assets/86306862/806626c2-68d8-4bfd-b5e2-6a46c1c107ed)

**USER | EDIT PROFILE**

![image](https://github.com/Karthikg1908/Hospital-Management-System/assets/86306862/d792c517-1fb9-492b-9ebf-7ec940b07c18)

**Patient Registration**

![image](https://github.com/Karthikg1908/Hospital-Management-System/assets/86306862/7680678d-cdcb-45ea-a7b3-729d7654dfb9)

**Database**

![image](https://github.com/Karthikg1908/Hospital-Management-System/assets/86306862/d90bfd30-fbc8-4206-832c-2eb685f43307)

**Database Design**

![image](https://github.com/Karthikg1908/Hospital-Management-System/assets/86306862/71e01826-2737-4491-8020-497922f60a3a)
